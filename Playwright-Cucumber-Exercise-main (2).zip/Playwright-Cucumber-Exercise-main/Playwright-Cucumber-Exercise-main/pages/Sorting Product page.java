@Before
public void initVariables () {
    
    HashMap<Float, String> map = new HashMap<>();
    map.put(7.99, "Sauce Labs Onesie");
    map.put(9.99, "Sauce Labs Bike Light");
    map.put(15.99, "Sauce Labs Bolt T-Shirt");
    map.put(15.99, "Test.alltheThings()T-Shirt(Red)");
    map.put(29.99, "Sauce Labs Backpack");
    map.put(49.99, "Sauce Labs Fleece Jacket");
    
}


@Test
public void givenMap_whenSortingByKeys_thenSortedMap() {
    Integer[] sortedKeys = new Integer[] {7.99, 9.99, 15.99, 15.99, 29.99, 49.99};

    List<Map.Entry<Float, String>> entries 
      = new ArrayList<>(map.entrySet());
    Collections.sort(entries, new Comparator<Entry<Float, String>>() {
        @Override
        public int compare(
          Entry<Float, String> o1, Entry<Float, String> o2) {
            return o1.getKey().compareTo(o2.getKey());
        }
    });
    Map<Float, String> sortedMap = new LinkedHashMap<>();
    for (Map.Entry<Float, String> entry : entries) {
        sortedMap.put(entry.getKey(), entry.getValue());
    }
        
    assertTrue(Arrays.equals(sortedMap.keySet().toArray(), sortedKeys));
}