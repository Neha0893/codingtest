import { Page } from "@playwright/test"

export class Product {
    private readonly page: Page
    private readonly addToCart: string = 'button[id="add-to-cart-sauce-labs-backpack"]'
    String = "FirstName";
    String = "LastName";
    String="Zip/Postal Code";
    constructor(page: Page) {
        this.page = page;
    }

    public async addBackPackToCart() {
        await this.page.locator(this.addToCart).click()
    }

    public async navigatetocart(){
        await this.page.locator(this.navigatetocart).click()
    }
    public async selectthecheckout(){
        await this.page.locator(this.selectthecheckout).click()
        
        final TextField Name = new TextField();
        FirstName.setPromptText("Enter your First Name.");
        LastName.setPromptText("Enter your Last Name.");
        Zipcode.setPromptText("Enter your zip/postal code");


        public async selectthecontinue(){
            await this.page.locator(this.selectthecontinue).click()

            public async selecttheFinish(){
                await this.page.locator(this.selecttheFinish).click()

                try
{
  Assert.IsTrue(verifyTextPresent("Thank you for your order!"));
  Console.WriteLine("Thank you for your order!");
}
catch (Exception)
{
  Console.WriteLine("Thank you for your order! is not present on the saucedemo page");
}
            


    

    


    }


}